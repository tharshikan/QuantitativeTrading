class TimeRule(object):
    def emitTimeToTrade(self):
        raise NotImplementedError
